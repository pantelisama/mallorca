#!/usr/bin/env node
// Refreshes pois.json (fuel stations, supermarkets, toilets for all of Mallorca) from OpenStreetMap.
// Usage: node scripts/update-pois.js   (Node 18+). Retries across Overpass mirrors, one type at a time,
// because the public servers often answer "too busy" to a single big query.
const fs = require("node:fs");
const path = require("node:path");

const BBOX = "(39.25,2.30,39.97,3.48)"; // south,west,north,east
const QUERIES = {
  f: 'nwr["amenity"="fuel"]' + BBOX,
  m: 'nwr["shop"="supermarket"]' + BBOX,
  w: 'nwr["amenity"="toilets"]' + BBOX
};
const MIRRORS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter"
];

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fetchType(q) {
  for (let attempt = 0; attempt < 12; attempt++) {
    const url = MIRRORS[attempt % MIRRORS.length];
    try {
      const res = await fetch(url, {
        method: "POST",
        signal: AbortSignal.timeout(60000),
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "data=" + encodeURIComponent("[out:json][timeout:60];(" + q + ";);out center tags;")
      });
      const text = await res.text();
      if (text.trim().startsWith("{")) return JSON.parse(text).elements;
      console.warn(url, "busy, retrying…");
    } catch (e) {
      console.warn(url, e.message);
    }
    await sleep(3000);
  }
  throw new Error("All Overpass mirrors failed");
}

(async () => {
  const out = {};
  for (const [k, q] of Object.entries(QUERIES)) {
    const els = await fetchType(q);
    out[k] = els.map(e => {
      const t = e.tags || {};
      const lat = e.lat ?? e.center?.lat, lng = e.lon ?? e.center?.lon;
      if (lat == null) return null;
      const name = t.name || t.brand || "";
      const brand = t.brand && t.brand !== name ? t.brand : "";
      const row = [+lat.toFixed(5), +lng.toFixed(5), name];
      if (t.opening_hours || brand || t.fee) row.push(t.opening_hours || "");
      if (brand || t.fee) row.push(brand);
      if (t.fee) row.push(t.fee);
      return row;
    }).filter(Boolean);
    console.log(k, out[k].length);
  }
  fs.writeFileSync(path.join(__dirname, "..", "pois.json"), JSON.stringify(out) + "\n");
})();
