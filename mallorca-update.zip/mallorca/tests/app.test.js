const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const vm = require("node:vm");

const root = path.resolve(__dirname, "..");
const appPath = path.join(root, "app.js");
const app = fs.readFileSync(appPath, "utf8");

test("app.js passes Node syntax validation", () => {
  const result = spawnSync(process.execPath, ["--check", appPath], { encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
});

test("spot cards do not use placeholder imagery", () => {
  assert.doesNotMatch(app, /images\.unsplash\.com/);
  assert.doesNotMatch(app, /\$\{s\.photo\|\|/);
  assert.doesNotMatch(app, /loremflickr/, "loremflickr is down; use the local SVG placeholder");
});

function runApp({ withLeaflet }) {
  const elements = new Map();
  const listeners = {};
  const makeEl = () => ({
    innerHTML: "",
    textContent: "",
    classList: { add() {}, remove() {}, toggle() {} },
    scrollIntoView() {}
  });
  const document = {
    querySelector(selector) {
      if (!elements.has(selector)) elements.set(selector, makeEl());
      return elements.get(selector);
    },
    addEventListener(type, fn) { (listeners[type] = listeners[type] || []).push(fn); }
  };

  const layer = () => ({
    addTo() { return this; },
    clearLayers() { return this; },
    on() { return this; },
    bindPopup() { return this; },
    bindTooltip() { return this; }
  });
  const map = {
    setView() { return this; },
    hasLayer() { return true; },
    addLayer() {},
    removeLayer() {},
    fitBounds() {},
    on() { return this; },
    addControl() { return this; },
  };
  const L = {
    map: () => map,
    tileLayer: () => layer(),
    layerGroup: () => layer(),
    polygon: () => layer(),
    divIcon: () => ({}),
    marker: () => layer(),
    polyline: () => layer(),
    latLngBounds: points => points,
    Control: { extend: () => function () {} },
    popup: () => ({ setLatLng() { return this; }, setContent() { return this; }, openOn() { return this; } })
  };

  const window = { open() {} };
  if (withLeaflet) window.L = L;
  const context = {
    console,
    document,
    window,
    ...(withLeaflet ? { L } : {}),
    fetch: async () => ({ ok: false }),
    setTimeout,
    clearTimeout
  };
  vm.runInNewContext(app, context, { filename: appPath });
  elements.clickDay = id => {
    const target = { closest: sel => (sel === "#days [data-day]" ? { dataset: { day: id } } : null) };
    for (const fn of listeners.click || []) fn({ target });
  };
  return elements;
}

test("render smoke test creates the main planner sections", () => {
  const elements = runApp({ withLeaflet: true });
  assert.match(elements.get("#plan").innerHTML, /Παρ 16 · Πρόγραμμα/);
  assert.ok(elements.get("#days").innerHTML.includes("Σαβ 17"));
  assert.match(elements.get("#filters").innerHTML, /Χωριά/);
});

test("planner still renders when Leaflet fails to load", () => {
  const elements = runApp({ withLeaflet: false });
  assert.match(elements.get("#plan").innerHTML, /Παρ 16 · Πρόγραμμα/);
  assert.match(elements.get("#map").innerHTML, /Ο χάρτης δεν φόρτωσε/);
});

test("index.html loads the planner shell and app.js", () => {
  const result = spawnSync(process.execPath, [path.join(root, "scripts", "validate-html.js")], { cwd: root, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  assert.match(html, /leaflet\.markercluster/);
});

test("map has on/off layers for fuel, supermarkets, toilets and food from the bundled snapshot", () => {
  assert.match(app, /pois\.json/);
  const pois = JSON.parse(fs.readFileSync(path.join(root, "pois.json"), "utf8"));
  for (const k of ["f", "m", "w"]) assert.ok(pois[k].length > 50, k + " should have island-wide points");
  for (const k of ["fuel", "market", "wc", "food"]) assert.match(app, new RegExp("\\b" + k + ":\\{label:"));
});

test("every day has a route with bundled road geometry, and no demo content", () => {
  assert.match(app, /const areas=\[\s*\]/);
  const geo = JSON.parse(fs.readFileSync(path.join(root, "routes-geo.json"), "utf8"));
  for (const id of ["fri", "sat", "sun", "mon"]) {
    assert.match(app, new RegExp("\\b" + id + ":\\{stops:\\["), id + " route missing");
    assert.ok(geo[id] && geo[id].length > 20, id + " road geometry missing");
  }
  for (const fake of ["Caimari", "village(\"lluc\"", "Photo stop", "Hotel Can Cera"]) assert.ok(!app.includes(fake), fake + " should be gone");
});

test("the four wineries show on every day in their own category", () => {
  const elements = runApp({ withLeaflet: true });
  for (const id of ["fri", "sat", "sun", "mon"]) {
    elements.clickDay(id);
    const html = elements.get("#plan").innerHTML;
    for (const name of ["Bodega Ribas", "Bodegues José L. Ferrer", "Macià Batle", "Miquel Oliver"]) {
      assert.match(html, new RegExp(name), name + " missing on " + id);
    }
  }
  assert.match(elements.get("#filters").innerHTML, /Οινοποιεία/);
});

test("the five villages show on every day, as places rather than stops", () => {
  const elements = runApp({ withLeaflet: true });
  for (const id of ["fri", "sat", "sun", "mon"]) {
    elements.clickDay(id);
    const html = elements.get("#plan").innerHTML;
    for (const name of ["Fornalutx", "Valldemossa", "Deià", "Sóller", "Alcúdia Old Town", "Santanyí"]) {
      assert.match(html, new RegExp(name), name + " missing on " + id);
    }
  }
});

test("the four days show their numbered stops", () => {
  const elements = runApp({ withLeaflet: true });
  assert.match(elements.get("#days").innerHTML, /Παρ 16/);
  for (const id of ["fri", "sat", "sun", "mon"]) {
    elements.clickDay(id);
    const html = elements.get("#plan").innerHTML;
    assert.match(html, /stop-card/, id + " should show stop cards");
    assert.doesNotMatch(html, /\b0 στάσεις/, id + " should not report zero stops");
  }
});

test("all places from Anna's food & drink list are tagged Anna", () => {
  const anna = ["El Camino", "Tast Club", "DÔME", "Pasta e Pesto", "Bibap", "El Cuerno", "Bacán", "Fika Farina", "La Rosa Vermutería", "Bar Nicolás", "Bar Central", "Bar Rey Sancho", "Primo Taquería", "Hostal Cuba Skybar", "Bacán (Seafront)", "El Olivo", "Foradada Mar", "Roseta", "Jumeirah Mallorca", "OCRE Restaurant", "Es Figueral", "Paparazzi", "Roosevelvet", "Serra de Tramuntana"];
  for (const n of anna) {
    const line = app.split("\n").find(l => l.includes('n:"') && l.includes(n));
    assert.ok(line, n + " missing");
    assert.match(line, /by:"Anna"/, n + " should be tagged Anna");
  }
});

test("categories live in a vertical slide-out drawer", () => {
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  assert.match(html, /id="cat-drawer"[\s\S]*id="filters"/);
  assert.match(fs.readFileSync(path.join(root, "styles.css"), "utf8"), /\.cat-drawer\.open/);
});

test("map layer buttons for fuel, supermarkets, toilets and food survive the cleanup", () => {
  for (const k of ["fuel", "market", "wc", "food"]) assert.match(app, new RegExp("\\b" + k + ":\\{label:"));
});

test("index.html still loads the planner shell", () => {
  const result = spawnSync(process.execPath, [path.join(root, "scripts", "validate-html.js")], { cwd: root, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
});
